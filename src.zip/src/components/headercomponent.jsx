import React from 'react'

const HeaderComponent = () => {
  return (
    <div>
      <header style={{ width: '100%'}}>
        <nav className='navbar navbar-dark bg-dark' style={{ justifyContent: 'center', backgroundColor: '#343a40'}}>
          <a className='navbar-brand' href='https://www.techcarrot.com'>
            Employee Management System
          </a>
        </nav>
      </header>
    </div>
  )
}

export default HeaderComponent
