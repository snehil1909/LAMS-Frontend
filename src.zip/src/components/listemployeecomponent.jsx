import { useNavigate } from 'react-router-dom';
import './listemployeecomponent.css'; // Import the CSS file
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { listemployees } from '../services/employeeservice';

const ListEmployeeComponent = () => {
  const [employees, setEmployees] = useState([]);
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    listemployees()
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error('Error fetching employees:', error);
      });
  }, []);

  // Define the addNewEmployee function
  const addNewEmployee = () => {
    navigate('/add-employee'); // Navigate to the "Add Employee" page
  };

  const deleteEmployee = (id) => {
    if (window.confirm("Are you sure you want to delete this employee?")) {
      axios
        .delete(`http://192.168.47.134:5000/api/users/${id}`) // Updated to match your DeleteMapping API path
        .then(() => {
          alert("Employee deleted successfully!");
          // Refresh the employee list
          listemployees()
            .then((response) => {
              setEmployees(response.data);
            })
            .catch((error) => {
              console.error('Error refreshing employee list:', error);
            });
        })
        .catch((error) => {
          console.error("Error deleting employee:", error);
          alert("Failed to delete employee. Please try again.");
        });
    }
  };

  return (
    <div className="page-container">
      <div className="content-wrap">
        <div className="container">
          <h2 className="text-center">List of Employees</h2>
          <button className="btn btn-primary mb-2" onClick={addNewEmployee}>
            Add Employee
          </button>
          <table className="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee) => (
                <tr key={employee.employeeId}>
                    
                  <td>{employee.employeeId}</td>
                  <td>{employee.firstName}</td>
                  <td>{employee.lastName}</td>
                  <td>{employee.email}</td>
                  <td>
                    <button
                      className="btn btn-info me-2"
                      onClick={() => navigate(`/profile/${employee.userId}`)}
                    >
                      View Profile
                    </button>
                    <button
                      className="btn btn-warning me-2"
                      onClick={() => navigate(`/update-employee/${employee.employeeId}`)}
                    >
                      Update
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => deleteEmployee(employee.employeeId)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ListEmployeeComponent;



